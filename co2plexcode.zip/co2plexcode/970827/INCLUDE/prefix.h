#ifndef  __PREFIX_H
#define  __PREFIX_H

#define CC_PROTOTYPE_ANSI

#include <stdio.h>
#include <stdlib.h>

#endif  /* __PREFIX_H */
